from flask import Flask, request
from markupsafe import escape
from flask import render_template
from elasticsearch import Elasticsearch
import math


# Change pasword
ELASTIC_PASSWORD = "sian1234"

es = Elasticsearch("https://localhost:9200", http_auth=("elastic", ELASTIC_PASSWORD), verify_certs=False)
app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')


# Check index name before perform "flask run"
@app.route('/search')
def search():
    page_size = 10
    keyword = request.args.get('keyword', '').strip()
    if request.args.get('page'):
        page_no = int(request.args.get('page'))
    else:
        page_no = 1
    
    # If no keyword, return all results
    if not keyword:
        body = {
            "size": page_size,
            "from": page_size * (page_no - 1),
            "query": {
                "match_all": {}
            },
            "sort": [
                {"normalized_salary": "desc"}
            ]
        }
    else:
        # Existing search logic for when keyword is provided
        try:
            salary_value = float(keyword)
            body = {
                "size": page_size,
                "from": page_size * (page_no - 1),
                "query": {
                    "function_score": {
                        "query": {
                            "range": {
                                "normalized_salary": {
                                    "gte": salary_value * 0.95,
                                    "lte": salary_value * 1.05
                                }
                            }
                        },
                        "gauss": {
                            "normalized_salary": {
                                "origin": salary_value,
                                "scale": salary_value * 0.025,
                                "decay": 0.5
                            }
                        }
                    }
                }
            }
        except ValueError:
            # Text search logic remains the same
            body = {
                "size": page_size,
                "from": page_size * (page_no - 1),
                "query": {
                    "bool": {
                        "should": [
                            {
                                "match_phrase_prefix": {
                                    "speciality": {
                                        "query": keyword,
                                        "slop": 0
                                    }
                                }
                            },
                            {
                                "multi_match": {
                                    "query": keyword,
                                    "fields": [
                                        "title^5",
                                        "speciality^4",
                                        "company_name^3",
                                        "industry^3",
                                        "description_x^2",
                                        "formatted_work_type^1",
                                        "normalized_salary^1",
                                        "country^1"
                                    ],
                                    "type": "most_fields",
                                    "lenient": "true",
                                    "minimum_should_match": "75%",
                                    "fuzziness": "AUTO",
                                    "prefix_length": 2,
                                    "zero_terms_query": "all"
                                }
                            }
                        ],
                        "minimum_should_match": 1
                    }
                },
                "sort": [
                    {"_score": "desc"},
                    {"normalized_salary": "desc"}
                ]
            }

    res = es.search(index='job_postings', body=body)
    hits = [
    {
        'company_id': doc['_source'].get('company_id'),
        'company_name': doc['_source'].get('company_name'),
        'title': doc['_source'].get('title'),
        'industry': doc['_source'].get('industry'),
        'speciality': doc['_source'].get('speciality'),
        'country': doc['_source'].get('country'),
        'state': doc['_source'].get('state'),
        'formatted_work_type': doc['_source'].get('formatted_work_type'),
        'normalized_salary': doc['_source'].get('normalized_salary'),
        'description_x': doc['_source'].get('description_x', 'No description available'),
        'company_logo': doc['_source'].get('company_logo', 'pic not found'),
        'score': doc['_score'],
        'job_posting_url': doc['_source'].get('job_posting_url', 'pic not found')
    } for doc in res['hits']['hits']
    ]

    page_total = math.ceil(res['hits']['total']['value']/page_size)
    return render_template('search.html', keyword=keyword, hits=hits, page_no=page_no, page_total=page_total)